# AI_Interface_Generator

AI-driven interface generation framework — Internship Project

---

## Project Overview

This project is a modular, AI-powered prompt code generator. Enter a prompt (e.g., "Create a responsive navbar") and the app instantly generates a working code snippet with syntax highlighting and copy support. The platform features a searchable prompt library, a modular page/component structure, and a clean, modern UI — all designed for maintainability and ease of client review.

---

## How to Run This Project

1. **Install VS Code**  
   Download from: https://code.visualstudio.com/

2. **Open the Project Folder**  
   - Launch VS Code  
   - Go to File > Open Folder… and select the project folder

3. **Use Live Server Extension**  
   - Search for “Live Server” in the Extensions sidebar and install it  
   - Right-click on any `.html` file (e.g., `welcome.html`) and select “Open with Live Server”  
   - The app will open in your browser (e.g., http://localhost:5500)

---

## Project Structure
AI_INTERFACE_GENERATOR/
│
├── docs/ # Documentation and weekly reports
├── public/
│ ├── welcome.html
│ ├── CodeGenerator.html
│ ├── PromptLibrary.html
│ ├── Login.html
│ ├── Signup.html
│ └── src/
│ ├── components/
│ │ ├── Header.html
│ │ ├── Footer.html
│ │ ├── GeneratorForm.html
│ │ ├── OutputBox.html
│ │ ├── InfoRow.html
│ │ ├── PromptCard.html
│ │ ├── PromptGrid.html
│ │ └── SearchBar.html
│ └── scripts/
│ ├── generator.js
│ └── promptLibrary.js
├── README.md


---

## Final Site Map: AI-Powered Platform Builder

- **Welcome / Landing Page**
- **Login / Signup Page**
- **Code Generator Page**
  - GeneratorForm (input + generate button)
  - OutputBox (code preview + copy/download)
  - InfoRow (tips/help)
- **Prompt Library Page**
  - SearchBar
  - PromptGrid (list of PromptCard)
  - PromptCard (prompt details, copy, sample)
- *(Optional)* Dashboard / User Profile Page
- *(Optional)* FAQ / Help / About Page
- *(Optional)* Settings Page

---

## Pipeline Usage

The **Code Generation Pipeline** follows a simple, modular process from user input to final output, ensuring smooth and responsive interaction.

1. **User Prompt Input**  
   - The user types a description of the desired UI/component (e.g., *"Create a responsive navbar"*).  
   - Input is validated to ensure it meets the minimum length requirement before processing.

2. **Code Generation Trigger**  
   - Clicking the **Generate Code** button starts the generation process.  
   - A loading spinner is displayed until the output is ready.

3. **Code Rendering & Highlighting**  
   - The generated code is instantly rendered in the **Output Box**.  
   - Basic syntax highlighting is applied for improved readability.  
   - The output area supports horizontal and vertical scrolling for long snippets.

4. **User Actions on Output**  
   - **Copy Code** — Copies the generated code to the clipboard with a confirmation message.  
   - **Download Code** — Downloads the generated code as a `.txt` file.  
   - **Error Handling** — Displays an error message if the prompt is invalid or generation fails.

5. **Responsiveness & Accessibility**  
   - All components are mobile-friendly and accessible.  
   - Buttons and labels include clear hover/focus states for better usability.

---

## Code Generation Pipeline Requirements

- [X] User can enter a prompt describing UI/code needs
- [X] Prevent empty prompt submissions (input validation)
- [X] “Generate” button triggers code creation and shows loading feedback (spinner)
- [X] Output area displays generated code with syntax highlighting
- [X] Output is scrollable for long code snippets
- [X] “Copy Code” button copies code to clipboard and shows confirmation
- [X] “Download Code” button lets user download code as `.txt`
- [X] Display error messages for invalid input or generator errors
- [X] Responsive output area and accessible buttons/labels

---

## Notes

- **Always use Live Server:** Opening `.html` files directly (with double-click or via `file://`) may cause some features (like JavaScript or dynamic prompt buttons) not to work.  
- **No build tools or Node.js needed:** Runs with CDN links and plain HTML/JS.  
- **Deployment:** For Netlify or Vercel, simply deploy the folder as a static site.  
- **Project Timeline:** All code and features developed as part of my EIM NetTech internship project (July–September 2025).

---

## Credits

Developed by **Karthik Desina**  
Internship: **EIM NetTech** (July–September 2025)
