const PROMPTS = [
  {
    title: "Create a Responsive Navbar",
    description: "Generate a modern responsive navigation bar using Tailwind CSS.",
    promptText: "Create a responsive navbar",
    sampleOutput: `<nav class='bg-blue-600 text-white p-4'>
  <ul class='flex space-x-4'>
    <li>Home</li>
    <li>Features</li>
    <li>Contact</li>
  </ul>
</nav>`
  },
  {
    title: "Design a Contact Form",
    description: "Build a contact form with name, email, subject, and message fields.",
    promptText: "Design a contact form",
    sampleOutput: `<form class='max-w-md mx-auto bg-white p-4 rounded'>
  <input type='text' placeholder='Name' class='mb-2 w-full border rounded p-2' />
  <input type='email' placeholder='Email' class='mb-2 w-full border rounded p-2' />
  <input type='text' placeholder='Subject' class='mb-2 w-full border rounded p-2' />
  <textarea placeholder='Message' class='mb-2 w-full border rounded p-2'></textarea>
  <button type='submit' class='w-full bg-blue-600 text-white rounded p-2'>Send</button>
</form>`
  },
  {
    title: "Build a Pricing Table",
    description: "Display pricing options for your SaaS product in a clean grid layout.",
    promptText: "Build a pricing table",
    sampleOutput: `<section class='grid grid-cols-1 md:grid-cols-3 gap-4'>
  <div class='bg-white shadow rounded p-4'>
    <h3>Basic</h3>
    <p>$10/month</p>
  </div>
  <div class='bg-white shadow rounded p-4'>
    <h3>Pro</h3>
    <p>$30/month</p>
  </div>
  <div class='bg-white shadow rounded p-4'>
    <h3>Enterprise</h3>
    <p>Contact Us</p>
  </div>
</section>`
  },
  {
    title: "Create a Login Form",
    description: "Generate a login form with email and password fields, plus a submit button.",
    promptText: "Create a login form",
    sampleOutput: `<form class='max-w-sm mx-auto p-4 bg-white rounded'>
  <input type='email' placeholder='Email' class='mb-2 w-full border rounded p-2' />
  <input type='password' placeholder='Password' class='mb-2 w-full border rounded p-2' />
  <button type='submit' class='w-full bg-blue-600 text-white rounded p-2'>Login</button>
</form>`
  }
];

// Card rendering function
function promptCardHTML(prompt) {
  return `
  <div class="bg-white shadow rounded-lg p-6 flex flex-col h-full">
    <h3 class="font-bold text-lg mb-2">${prompt.title}</h3>
    <p class="text-gray-600 flex-grow">${prompt.description}</p>
    <div class="mt-4 flex gap-2">
      <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition copy-prompt-btn" data-prompt="${prompt.promptText}">Copy Prompt</button>
      <button class="bg-gray-100 text-gray-800 px-4 py-2 rounded hover:bg-gray-200 transition view-sample-btn" data-sample="${encodeURIComponent(prompt.sampleOutput)}">View Sample</button>
    </div>
  </div>
  `;
}

function renderPromptGrid(prompts) {
  const grid = document.getElementById('promptGrid');
  if (!grid) return;
  grid.innerHTML = prompts.map(prompt => promptCardHTML(prompt)).join('');
}

function filterPrompts(query) {
  const q = query.trim().toLowerCase();
  if (!q) return PROMPTS;
  return PROMPTS.filter(p =>
    p.title.toLowerCase().includes(q) ||
    p.description.toLowerCase().includes(q) ||
    p.promptText.toLowerCase().includes(q)
  );
}

function attachPromptCardEvents() {
  const grid = document.getElementById('promptGrid');
  if (!grid) return;

  grid.addEventListener('click', function(e) {
    // Copy Prompt
    if (e.target.classList.contains('copy-prompt-btn')) {
      const promptText = e.target.getAttribute('data-prompt');
      navigator.clipboard.writeText(promptText);
      e.target.textContent = "Copied!";
      setTimeout(() => e.target.textContent = "Copy Prompt", 1200);
    }
    // Show Modal
    else if (e.target.classList.contains('view-sample-btn')) {
      const sample = decodeURIComponent(e.target.getAttribute('data-sample'));
      showSampleModal(sample);
    }
  });
}

// Modal logic
function showSampleModal(sampleCode) {
  const modal = document.getElementById("sampleModal");
  const modalContent = document.getElementById("modalSampleContent");
  modalContent.innerHTML = `<pre class="overflow-x-auto text-sm bg-gray-900 text-green-200 rounded p-4 whitespace-pre">${sampleCode.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>`;
  modal.classList.remove("hidden");
}
function hideSampleModal() {
  document.getElementById("sampleModal").classList.add("hidden");
}

window.addEventListener('DOMContentLoaded', () => {
  // Load PromptGrid.html, then render prompts and attach events
  fetch('src/components/PromptGrid.html')
    .then(res => res.text())
    .then(html => {
      document.getElementById('promptGridContainer').innerHTML = html;
      renderPromptGrid(PROMPTS);
      attachPromptCardEvents();

      // Search input
      const searchInput = document.getElementById('searchInput');
      if (searchInput) {
        searchInput.addEventListener('input', e => {
          renderPromptGrid(filterPrompts(e.target.value));
        });
      }
    });

  // Modal close events
  document.body.addEventListener("click", function(e) {
    if (e.target.id === "closeModalBtn" || e.target.id === "sampleModal") {
      hideSampleModal();
    }
  });
  document.addEventListener("keydown", function(e) {
    if (e.key === "Escape") hideSampleModal();
  });
});
