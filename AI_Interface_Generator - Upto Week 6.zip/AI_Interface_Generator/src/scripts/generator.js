function initGeneratorFormListeners() {
  const generatorForm = document.getElementById('generatorForm');
  const generateBtn = document.getElementById("generateBtn");
  const promptInput = document.getElementById("promptInput");
  const errorText = document.getElementById("errorText");
  const codeOutput = document.getElementById("codeOutput");
  const btnText = document.getElementById("btnText");
  const spinner = document.getElementById("spinner");
  const copyContainer = document.getElementById("copyContainer");
  const copyBtn = document.getElementById("copyBtn");
  const downloadBtn = document.getElementById("downloadBtn");
  const copyStatus = document.getElementById("copyStatus");

  // 1. Prevent form default submit behavior
  if (generatorForm) {
    generatorForm.addEventListener('submit', function(e) {
      e.preventDefault();
    });
  }

  // 2. Sample Prompt Card click to fill input (form and bottom of main page)
  document.querySelectorAll(".prompt-card").forEach(card => {
    // Remove any existing click listeners to prevent stacking (best practice)
    card.replaceWith(card.cloneNode(true));
  });
  document.querySelectorAll(".prompt-card").forEach(card => {
    card.addEventListener("click", () => {
      if (promptInput) promptInput.value = card.textContent;
    });
  });

  // 3. Generate Button click logic (NOW WITH SPINNER DELAY)
  if (generateBtn) {
    generateBtn.addEventListener("click", () => {
      const prompt = promptInput.value.trim();

      if (prompt === "" || prompt.length < 10) {
        if (errorText) errorText.classList.remove("hidden");
        if (codeOutput) codeOutput.classList.add("hidden");
        if (copyContainer) copyContainer.classList.add("hidden");
        if (generateBtn) generateBtn.disabled = false;
        if (btnText) btnText.textContent = "Generate Code";
        if (spinner) spinner.classList.add("hidden");
        return;
      }

      if (errorText) errorText.classList.add("hidden");
      if (generateBtn) generateBtn.disabled = true;
      if (btnText) btnText.textContent = "Generating...";
      if (spinner) spinner.classList.remove("hidden");

      // --- SHOW SPINNER FOR 1 SECOND BEFORE SHOWING CODE ---
      setTimeout(() => {
        let generatedCode = "";

        if (prompt.toLowerCase().includes("navbar")) {
          generatedCode = `<nav class="bg-blue-600 text-white p-4">
  <ul class="flex space-x-4">
    <li>Home</li>
    <li>Features</li>
    <li>Contact</li>
  </ul>
</nav>`;
        } else if (prompt.toLowerCase().includes("pricing")) {
          generatedCode = `<section class="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
  <div class="bg-white shadow rounded p-4 text-center">
    <h3 class="text-lg font-bold">Basic</h3>
    <p class="text-xl font-semibold">$10/month</p>
  </div>
  <div class="bg-white shadow rounded p-4 text-center">
    <h3 class="text-lg font-bold">Pro</h3>
    <p class="text-xl font-semibold">$30/month</p>
  </div>
  <div class="bg-white shadow rounded p-4 text-center">
    <h3 class="text-lg font-bold">Enterprise</h3>
    <p class="text-xl font-semibold">Contact Us</p>
  </div>
</section>`;
        } else if (prompt.toLowerCase().includes("login")) {
          generatedCode = `<form class="max-w-sm mx-auto p-4 bg-white shadow-md rounded">
  <label class="block mb-2 text-sm font-medium text-gray-700">Email</label>
  <input type="email" class="w-full p-2 mb-4 border border-gray-300 rounded" placeholder="you@example.com" />
  <label class="block mb-2 text-sm font-medium text-gray-700">Password</label>
  <input type="password" class="w-full p-2 mb-4 border border-gray-300 rounded" placeholder="••••••••" />
  <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded">Login</button>
</form>`;
        } else {
          generatedCode = "// Feature coming soon: real-time AI-powered generation";
        }

        if (codeOutput) codeOutput.innerHTML = highlightCode(generatedCode);
        if (codeOutput) codeOutput.classList.remove("hidden");
        if (copyContainer) copyContainer.classList.remove("hidden");

        if (generateBtn) generateBtn.disabled = false;
        if (btnText) btnText.textContent = "Generate Code";
        if (spinner) spinner.classList.add("hidden");
      }, 1000); // <-- 1 second delay
    });
  }

  // 4. Copy Button click logic
  if (copyBtn) {
    copyBtn.addEventListener("click", () => {
      const tempEl = document.createElement("textarea");
      tempEl.value = codeOutput ? codeOutput.textContent : '';
      document.body.appendChild(tempEl);
      tempEl.select();
      document.execCommand("copy");
      document.body.removeChild(tempEl);

      if (copyStatus) copyStatus.classList.remove("hidden");
      setTimeout(() => {
        if (copyStatus) copyStatus.classList.add("hidden");
      }, 2000);
    });
  }

  // 5. Download Button click logic (fixed location & style)
  if (downloadBtn) {
    downloadBtn.addEventListener("click", () => {
      const codeText = codeOutput ? codeOutput.textContent : '';
      const blob = new Blob([codeText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "generated-code.txt";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }
}

// REMOVE window.addEventListener("DOMContentLoaded", ...) here!
// Only call initGeneratorFormListeners() after BOTH GeneratorForm and OutputBox are loaded, using maybeInitGeneratorListeners in codegenerator.html

function highlightCode(code) {
  return code
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\b(const|function|return|let|var|if|else)\b/g, '<span class="text-blue-400">$1</span>')
    .replace(/("[^"]*"|'[^']*')/g, '<span class="text-yellow-300">$1</span>')
    .replace(/(\d+)/g, '<span class="text-pink-400">$1</span>')
    .replace(/(\/\/.*)/g, '<span class="text-gray-500 italic">$1</span>');
}
