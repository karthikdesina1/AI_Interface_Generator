window.addEventListener("DOMContentLoaded", () => {
  const generateBtn = document.getElementById("generateBtn");
  const promptInput = document.getElementById("promptInput");
  const errorText = document.getElementById("errorText");
  const codeOutput = document.getElementById("codeOutput");
  const btnText = document.getElementById("btnText");
  const spinner = document.getElementById("spinner");
  const promptCards = document.querySelectorAll(".prompt-card");

  // ✅ Make prompt cards clickable
  promptCards.forEach(card => {
    card.addEventListener("click", () => {
      promptInput.value = card.textContent;
    });
  });

  generateBtn.addEventListener("click", () => {
    const prompt = promptInput.value.trim();

    if (prompt === "" || prompt.length < 10) {
      errorText.classList.remove("hidden");
      codeOutput.classList.add("hidden");
      return;
    }

    errorText.classList.add("hidden");
    generateBtn.disabled = true;
    btnText.textContent = "Generating...";
    spinner.classList.remove("hidden");

    setTimeout(() => {
      let generatedCode = "";

      if (prompt.toLowerCase().includes("navbar")) {
        generatedCode = `<nav class="bg-blue-600 text-white p-4">
  <ul class="flex space-x-4">
    <li>Home</li>
    <li>Features</li>
    <li>Contact</li>
  </ul>
</nav>`;
      } else if (prompt.toLowerCase().includes("pricing")) {
        generatedCode = `<section class="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
  <div class="bg-white shadow rounded p-4 text-center">
    <h3 class="text-lg font-bold">Basic</h3>
    <p class="text-xl font-semibold">$10/month</p>
  </div>
  <div class="bg-white shadow rounded p-4 text-center">
    <h3 class="text-lg font-bold">Pro</h3>
    <p class="text-xl font-semibold">$30/month</p>
  </div>
  <div class="bg-white shadow rounded p-4 text-center">
    <h3 class="text-lg font-bold">Enterprise</h3>
    <p class="text-xl font-semibold">Contact Us</p>
  </div>
</section>`;
      } else if (prompt.toLowerCase().includes("login")) {
        generatedCode = `<form class="max-w-sm mx-auto p-4 bg-white shadow-md rounded">
  <label class="block mb-2 text-sm font-medium text-gray-700">Email</label>
  <input type="email" class="w-full p-2 mb-4 border border-gray-300 rounded" placeholder="you@example.com" />
  
  <label class="block mb-2 text-sm font-medium text-gray-700">Password</label>
  <input type="password" class="w-full p-2 mb-4 border border-gray-300 rounded" placeholder="••••••••" />
  
  <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded">Login</button>
</form>`;
      } else {
        generatedCode = "// Feature coming soon: real-time AI-powered generation";
      }

      codeOutput.textContent = generatedCode;
      codeOutput.classList.remove("hidden");

      generateBtn.disabled = false;
      btnText.textContent = "Generate Code";
      spinner.classList.add("hidden");
    }, 800);
  });
});
